<?php
	// Root url for the site
	define('ROOT_URL', 'http://localhost/inventory/');
	
	
	// Database parameters
	// Data source name
	define('DSN', 'mysql:host=127.0.0.1:3308;dbname=shop_inventory');
	
	// Hostname
	define('DB_HOST', '127.0.0.1:3308');
	
	// DB user
	define('DB_USER', 'root');
	
	// DB password
	define('DB_PASSWORD', '');
	
	// DB name
	define('DB_NAME', 'shop_inventory');
?>